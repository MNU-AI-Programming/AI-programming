Week 4 실습 데이터 파일

1) grade_tests.csv
- 점수(score)와 기대 등급(expected) 목록
- 경계값(59/60/69/70/79/80/89/90) + 범위 밖(-1, 101) 포함

2) gugudan_inputs.txt
- 구구단 테스트용 입력 n 샘플(정상/이상 포함)

3) guess_config.json
- 숫자 맞히기 게임 설정(정답 target, 범위 min/max, max_tries)

4) primes_range.txt
- 소수 출력 도전 과제 범위(예: 1 100)
