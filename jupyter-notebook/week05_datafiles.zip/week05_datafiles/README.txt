Week 5 실습 데이터 파일

1) students_scores.csv
- 학생 이름과 점수
- 함수 설계/등급 계산/리팩터링 연습용

2) conversion_samples.json
- 단위 변환기 테스트 샘플 데이터
