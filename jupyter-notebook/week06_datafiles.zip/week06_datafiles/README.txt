Week 6 실습 데이터 파일

1) scores_samples.txt
- 점수 분석기 실습용 입력 샘플

2) todo_commands.txt
- TODO 리스트 프로그램 실행 예시 명령어

3) numbers_copy_test.txt
- 리스트 복사/참조 테스트용
