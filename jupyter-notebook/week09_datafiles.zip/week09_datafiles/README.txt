Week 9 실습 데이터 파일 모음

1) data.txt
- read / readline / readlines 실습용 텍스트

2) nums.txt
- 공백/줄바꿈 섞인 숫자 데이터 (합/평균/최대/최소)
- 엣지 케이스: nums_empty.txt (빈 파일)

3) grade.csv
- 성적표 CSV (name + 3과목)
- 심화/엣지 케이스: grade_missing.csv (결측 포함)

4) settings.json
- JSON 설정 파일 예시 (sound, level 등)

5) contacts_seed.json
- 연락처 초기 데이터(딕셔너리 seed)

6) sentence.txt
- 단어 빈도 분석 실습용 문장(공백/줄바꿈)

7) lotto_winning.json
- 로또 당첨 번호(교집합 계산용)
